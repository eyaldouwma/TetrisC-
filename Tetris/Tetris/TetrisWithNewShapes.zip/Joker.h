#ifndef __JOKER_H
#define __JOKER_H

#include "Point.h"
#include "GameBoard.h"

class Joker {
private:
	Point body;
	char symbol;
public:
	
	Joker(const Point& body = { 5,4 }, char symbol = '$');

	void setBody(const Point& body);

	const Point& getBody() const;

	void draw() const;

	void erase() const;

	char getSymbol() const;

	bool checkIfLRAvailable(char Key) const;
	
	bool checkIfDownAvailable() const;
	
	void goDown(const GameBoard& board, int& moveCounter);

	void move(char KeyPressed,const GameBoard& board,int& moveCounter);
};

#endif __JOKER_H
