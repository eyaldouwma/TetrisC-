#include "theGame.h"
#include <iostream>

using namespace std;

void main()
{
	
	theGame Game;

	Game.runWithMenuOptions();

	
	
	system("pause");

}