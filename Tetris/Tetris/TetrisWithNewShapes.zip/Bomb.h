#ifndef __BOMB_H
#define __BOMB_H
#include "Point.h"
#include "GameBoard.h"

enum eResult { False, True, FALSE_DEFAULT };

class Bomb
{
private:
	char symbol;
	Point body;

public:
	Bomb(const Point& body = { 5,4 }, char symbol = '@');

	void setBody(const Point& body);

	const Point& getBody () const;

	void draw() const;

	void erase() const;

	char getSymbol() const;

	eResult checkIfLRAvailable(char Key,const GameBoard& board) const;

	bool checkIfDownAvailable(const GameBoard& board) const;

	void move(char KeyPressed,const GameBoard& board,int& moveCounter,bool& explode);

	int explode(GameBoard &board);

	void goDown(int& moveCounter);



};

#endif __BOMB_H



