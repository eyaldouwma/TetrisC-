#ifndef __SHAPE_H
#define __SHAPE_H

#include <iostream>
#include "Point.h"
#include "GameBoard.h"

using namespace std;

enum ePosition{upPos, downPos, leftPos, rightPos};

class Shape
{
protected:
	Point body[4];
	char symbol;

public:
	
	Shape(char symbol);

	char getSymbol() const;

	virtual void setBody(const Point& head) = 0;

	const Point* getBody() const;

	const Point& getPointFromBody(int i) const;

	void draw() const;

	void erase() const;

	bool checkIfLRAvailable(char direction, const GameBoard& board) const;

	bool checkIfDownAvailable(const GameBoard& board) const;

	void goDown(int& moveCounter);

	void move(char direction, const GameBoard &board, int& moveCounter);

	virtual bool checkAvailabilityToRotate(const GameBoard &board) const = 0 ;

	virtual void rotate(const GameBoard &board, int& moveCounter) = 0;

	//~Shape(); // delete body[]

};

#endif __SHAPE_H