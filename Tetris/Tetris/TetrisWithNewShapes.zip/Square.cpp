#include <iostream>
#include "Point.h"
#include "Gotoxy.h"
#include "Square.h"
#include "GameBoard.h"
#include "Utils.h"

using namespace std;

void Square::setBody(const Point& head)
{
	int x, y;

	x = head.getXCoordinate();
	y = head.getYCoordinate();

	body[0] = head;

	x++;

	body[1].setXYCoordinate(x, y);

	x--;
	y++;

	body[2].setXYCoordinate(x, y);

	x++;

	body[3].setXYCoordinate(x, y);
}
/*
void Square::draw() const
{
	int i, j;

	for (i = 0; i < 2; i++)
	{
		for (j = 0; j < 2; j++)
		{
			gotoxy(body[i][j].getXCoordinate(), body[i][j].getYCoordinate());
			cout << symbol;
		}
	}
	
}
void Square::erase() const
{
	int i, j;
	for (i = 0; i < 2; i++)
	{
		for (j = 0; j < 2; j++)
		{
			gotoxy(body[i][j].getXCoordinate(), body[i][j].getYCoordinate());
			cout << ' ';
		}
	}
	
}
const Point& Square::getPointFromBody(int i, int j)
{
	return body[i][j];
}

bool Square::checkIfLRAvailable(char direction,const GameBoard& board) const
{
	
	int row, col;
	col = body[0][0].getXCoordinate(); 
	row = body[0][0].getYCoordinate(); 

	switch(direction)
	{
		case Left: //left
		{
			if ((col > 1))
			{
				if ((board.getMatrixValueInCell(row-rowOffset,col-(1+columnOffset)) == -1) && (board.getMatrixValueInCell(row-(rowOffset-1),col-(columnOffset+1)) == -1))
					return true;
			}
			return false;
		}

		case Right: // right
		{
			if ((col < 9))
			{
				if ((board.getMatrixValueInCell(row-4,col+1)== -1) && (board.getMatrixValueInCell(row-3,col+1)== -1))
					return true;
			}
			return false;
		}
		default:
		{
			return false;
		}
	}
}

void Square::move(char direction,const GameBoard &board,int& moveCounter) 
{
	switch (direction)
	{
	case Left: // left
	{
		if (checkIfLRAvailable(direction, board) == true)
		{
			moveCounter++;
			int x;
			x = body[0][0].getXCoordinate();

			x--;

			erase();

			body[0][0].setXCoordinate(x);
			setBody(body[0][0]);


			draw();
		}
		else
		{
			goDown(moveCounter);
		}
		break;
	}
	case Right: //right
	{
		if (checkIfLRAvailable(direction, board) == true)
		{
			moveCounter++;
			int x;
			x = body[0][0].getXCoordinate();

			x++;

			erase();

			body[0][0].setXCoordinate(x);
			setBody(body[0][0]);

			draw(); 
		}
		else
		{
			goDown(moveCounter);
		}
		break;
	}
	case Down:
	{
		int y;
		erase();
		while (checkIfDownAvailable(board))
		{
			y = body[0][0].getYCoordinate();
			y++;

			body[0][0].setYCoordinate(y);
			setBody(body[0][0]);
		}
		y--;
		body[0][0].setYCoordinate(y);
		setBody(body[0][0]);
		draw();
	}
	default: //down
	{
		goDown(moveCounter);
		break;
	}
	}
}
bool Square::checkIfDownAvailable(const GameBoard& board) const
{
	int row, col;

	row = body[0][0].getYCoordinate();
	col = body[0][0].getXCoordinate();

	if (row < 17)
	{
		if ((board.getMatrixValueInCell(row-2, col-1) == -1) && (board.getMatrixValueInCell(row-2, col) == -1))
		{
			return true;
		}
	}
	return false;
}
char Square::getSymbol() const
{
	return symbol;
}
void Square::goDown(int& moveCounter)
{
	moveCounter = 0;
	int y;
	y = body[0][0].getYCoordinate();

	y++;

	erase();

	body[0][0].setYCoordinate(y);
	setBody(body[0][0]);

	draw();
}
*/
void Square::rotate(const GameBoard &board, int& moveCounter)
{
	goDown(moveCounter);
}