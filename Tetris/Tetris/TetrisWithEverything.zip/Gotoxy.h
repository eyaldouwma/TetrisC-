#ifndef _GOTOXY_H_
#define _GOTOXY_H_

void gotoxy(int, int); // prototype
void clrscr(); // prototype

#endif
